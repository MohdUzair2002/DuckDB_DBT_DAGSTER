


SELECT * 
FROM {{ ref('Sales_Product_Combined') }}  -- Reference the seed file


